define( function() {
	"use strict";

	return window.location;
} );
